package com.nabwitajir.courseregistration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseregistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
